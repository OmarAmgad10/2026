import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.teal.shade50, Colors.white],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Card(
            elevation: 12,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(25),
            ),
            shadowColor: Colors.tealAccent,
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                children: [
                  Icon(Icons.info_outline, size: 100, color: Colors.teal),
                  SizedBox(height: 20),
                  Text(
                    'About This App',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 15),
                  Text(
                    'This app demonstrates navigation between Home, About, and Contact pages using Flutter with a modern and clean UI design. It uses BottomNavigationBar for smooth navigation and responsive layouts for all devices.',
                    style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.flutter_dash, color: Colors.blue, size: 40),
                      SizedBox(width: 20),
                      Icon(Icons.code, color: Colors.green, size: 40),
                      SizedBox(width: 20),
                      Icon(Icons.devices, color: Colors.orange, size: 40),
                      SizedBox(width: 20),
                      Icon(Icons.palette, color: Colors.purple, size: 40), // إضافة أيقونة جديدة
                    ],
                  ),
                  SizedBox(height: 20),
                  // إضافة قائمة بميزات
                  Text(
                    'Key Features:',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal[700],
                    ),
                  ),
                  SizedBox(height: 10),
                  ListTile(
                    leading: Icon(Icons.check_circle, color: Colors.green),
                    title: Text('Easy Navigation'),
                  ),
                  ListTile(
                    leading: Icon(Icons.check_circle, color: Colors.green),
                    title: Text('Beautiful Design'),
                  ),
                  ListTile(
                    leading: Icon(Icons.check_circle, color: Colors.green),
                    title: Text('Fast Performance'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}